import{m as r}from"./index.86a88337.js";function m(e){return r.get({url:"/prize/get",params:{prizeId:e}})}export{m as g};
