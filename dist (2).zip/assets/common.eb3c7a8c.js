function t(){var r=navigator.userAgent,a=/Safari/.test(r)&&!/Chrome/.test(r);return!!a}export{t as i};
