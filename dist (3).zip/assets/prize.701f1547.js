import{m as r}from"./index.a4d38ea1.js";function m(e){return r.get({url:"/prize/get",params:{prizeId:e}})}export{m as g};
